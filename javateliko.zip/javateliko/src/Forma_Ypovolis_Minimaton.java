public class Forma_Ypovolis_Minimaton {
	
	
	public void Apostelei_minima_enimerosis() {
		System.out.println("Αποστολή μηνύματος ενημέρωσης");
	}
}